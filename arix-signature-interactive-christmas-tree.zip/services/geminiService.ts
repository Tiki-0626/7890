
import { GoogleGenAI } from "@google/genai";
import { SYSTEM_PROMPT } from "../constants";

export class ArixConciergeService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getResponse(userInput: string, history: {role: 'user' | 'model', parts: {text: string}[]}[]) {
    try {
      const model = 'gemini-3-flash-preview';
      const chat = this.ai.chats.create({
        model,
        config: {
          systemInstruction: SYSTEM_PROMPT,
          temperature: 0.8,
          topP: 0.9,
        }
      });

      const response = await chat.sendMessage({ message: userInput });
      return response.text || "The Arix Signature Tree glows in silent response to your presence.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "The mystical essence of Arix is momentarily quiet. Please, speak again.";
    }
  }
}
