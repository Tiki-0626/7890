
import React from 'react';
import { EffectComposer, Bloom, Noise, Vignette, ChromaticAberration } from '@react-three/postprocessing';
import { Vector2 } from 'three';

const PostProcessing: React.FC = () => {
  return (
    <EffectComposer disableNormalPass>
      <Bloom 
        luminanceThreshold={0.4} 
        mipmapBlur 
        intensity={1.2} 
        radius={0.4} 
      />
      <ChromaticAberration 
        offset={new Vector2(0.001, 0.001)} 
      />
      <Noise opacity={0.03} />
      <Vignette eskil={false} offset={0.1} darkness={0.8} />
    </EffectComposer>
  );
};

export default PostProcessing;
