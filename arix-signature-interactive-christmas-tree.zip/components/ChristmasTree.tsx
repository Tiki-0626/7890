
import React, { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { Sparkles } from '@react-three/drei';
import { 
  COLORS, 
  INITIAL_CONFIG, 
  FOLIAGE_COUNT, 
  ORNAMENT_COUNTS, 
  WEIGHTS, 
  SCATTER_RADIUS, 
  TREE_HEIGHT, 
  TREE_BASE_RADIUS 
} from '../constants';
import { TreeMorphStatus } from '../types';

interface ChristmasTreeProps {
  config: typeof INITIAL_CONFIG;
  status: TreeMorphStatus;
}

const ChristmasTree: React.FC<ChristmasTreeProps> = ({ config, status }) => {
  const { clock } = useThree();
  const groupRef = useRef<THREE.Group>(null);
  
  // Foliage Refs
  const foliagePointsRef = useRef<THREE.Points>(null);
  const foliageMaterialRef = useRef<THREE.ShaderMaterial>(null);

  // Ornament Refs
  const ballsRef = useRef<THREE.InstancedMesh>(null);
  const giftsRef = useRef<THREE.InstancedMesh>(null);
  const lightsRef = useRef<THREE.InstancedMesh>(null);

  const morphFactor = useRef(status === TreeMorphStatus.TREE_SHAPE ? 1 : 0);

  // --- Foliage Setup (Points + Shader) ---
  const foliagePointsData = useMemo(() => {
    const positions = new Float32Array(FOLIAGE_COUNT * 3);
    const scatterPositions = new Float32Array(FOLIAGE_COUNT * 3);
    const treePositions = new Float32Array(FOLIAGE_COUNT * 3);
    const randoms = new Float32Array(FOLIAGE_COUNT);

    for (let i = 0; i < FOLIAGE_COUNT; i++) {
      // Scatter
      const sR = Math.pow(Math.random(), 0.5) * SCATTER_RADIUS;
      const sTheta = Math.random() * Math.PI * 2;
      const sPhi = Math.acos(2 * Math.random() - 1);
      
      const sx = sR * Math.sin(sPhi) * Math.cos(sTheta);
      const sy = sR * Math.sin(sPhi) * Math.sin(sTheta);
      const sz = sR * Math.cos(sPhi);
      
      scatterPositions[i * 3] = sx;
      scatterPositions[i * 3 + 1] = sy;
      scatterPositions[i * 3 + 2] = sz;

      // Tree
      const tY = Math.random() * TREE_HEIGHT;
      const tRatio = 1 - (tY / TREE_HEIGHT);
      const tRadius = tRatio * TREE_BASE_RADIUS;
      const tAngle = Math.random() * Math.PI * 2;
      
      treePositions[i * 3] = Math.cos(tAngle) * tRadius;
      treePositions[i * 3 + 1] = tY - TREE_HEIGHT / 2;
      treePositions[i * 3 + 2] = Math.sin(tAngle) * tRadius;

      randoms[i] = Math.random();
    }

    return { scatterPositions, treePositions, randoms };
  }, []);

  const foliageShader = useMemo(() => ({
    uniforms: {
      uTime: { value: 0 },
      uMorph: { value: 0 },
      uColorLow: { value: new THREE.Color(COLORS.EMERALD_DARK) },
      uColorHigh: { value: new THREE.Color(COLORS.GOLD_BRIGHT) },
      uSize: { value: 4.0 }
    },
    vertexShader: `
      uniform float uTime;
      uniform float uMorph;
      attribute vec3 scatterPos;
      attribute vec3 treePos;
      attribute float aRandom;
      varying float vRandom;
      varying vec3 vPos;

      void main() {
        vRandom = aRandom;
        vec3 pos = mix(scatterPos, treePos, uMorph);
        
        // Add jitter/breathing
        float wave = sin(uTime * 1.5 + aRandom * 10.0) * 0.05 * (1.0 - uMorph * 0.5);
        pos += wave;
        
        vPos = pos;
        vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
        gl_PointSize = 4.0 * (1.0 + sin(uTime + aRandom * 6.28) * 0.2) * (15.0 / -mvPosition.z);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform vec3 uColorLow;
      uniform vec3 uColorHigh;
      varying float vRandom;
      varying vec3 vPos;

      void main() {
        float dist = distance(gl_PointCoord, vec2(0.5));
        if (dist > 0.5) discard;
        
        float glow = 0.5 - dist;
        vec3 baseColor = mix(uColorLow, vec3(0.04, 0.22, 0.15), vRandom);
        
        // Edge highlighting (Gold/White)
        float pulse = (sin(uTime * 2.0 + vRandom * 5.0) + 1.0) * 0.5;
        vec3 finalColor = mix(baseColor, uColorHigh, pulse * 0.4);
        
        gl_FragColor = vec4(finalColor, glow * 2.0);
      }
    `
  }), []);

  // --- Ornaments Setup ---
  const ornamentData = useMemo(() => {
    const generate = (count: number, baseRadiusOffset: number = 1.0) => {
      return Array.from({ length: count }).map((_, i) => {
        const sR = Math.pow(Math.random(), 0.5) * SCATTER_RADIUS;
        const sTheta = Math.random() * Math.PI * 2;
        const sPhi = Math.acos(2 * Math.random() - 1);
        const scatterPos = new THREE.Vector3(sR * Math.sin(sPhi) * Math.cos(sTheta), sR * Math.sin(sPhi) * Math.sin(sTheta), sR * Math.cos(sPhi));

        const tY = Math.random() * TREE_HEIGHT;
        const tRadius = (1 - (tY / TREE_HEIGHT)) * TREE_BASE_RADIUS * baseRadiusOffset;
        const tAngle = Math.random() * Math.PI * 2;
        const treePos = new THREE.Vector3(Math.cos(tAngle) * tRadius, tY - TREE_HEIGHT / 2, Math.sin(tAngle) * tRadius);

        return { scatterPos, treePos, random: Math.random(), size: 0.1 + Math.random() * 0.1 };
      });
    };

    return {
      balls: generate(ORNAMENT_COUNTS.BALLS, 1.05),
      gifts: generate(ORNAMENT_COUNTS.GIFTS, 0.8),
      lights: generate(ORNAMENT_COUNTS.LIGHTS, 1.1)
    };
  }, []);

  const dummy = new THREE.Object3D();

  useFrame((state, delta) => {
    const target = status === TreeMorphStatus.TREE_SHAPE ? 1 : 0;
    morphFactor.current = THREE.MathUtils.lerp(morphFactor.current, target, delta * 1.5);

    if (foliageMaterialRef.current) {
      foliageMaterialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      foliageMaterialRef.current.uniforms.uMorph.value = morphFactor.current;
    }

    if (groupRef.current) {
      groupRef.current.rotation.y += config.rotationSpeed * delta;
    }

    const updateInstance = (ref: React.RefObject<THREE.InstancedMesh>, data: any[], weight: number) => {
      if (!ref.current) return;
      data.forEach((d, i) => {
        const drift = (1 - morphFactor.current) * weight;
        const noise = new THREE.Vector3(
          Math.sin(state.clock.elapsedTime * 0.5 + i) * drift,
          Math.cos(state.clock.elapsedTime * 0.4 + i) * drift,
          Math.sin(state.clock.elapsedTime * 0.3 + i) * drift
        );
        const pos = new THREE.Vector3().lerpVectors(d.scatterPos, d.treePos, morphFactor.current).add(noise);
        dummy.position.copy(pos);
        dummy.rotation.set(d.random * 10, state.clock.elapsedTime * 0.2 + d.random, 0);
        const s = d.size * (0.6 + morphFactor.current * 0.4);
        dummy.scale.set(s, s, s);
        dummy.updateMatrix();
        ref.current!.setMatrixAt(i, dummy.matrix);
      });
      ref.current.instanceMatrix.needsUpdate = true;
    };

    updateInstance(ballsRef, ornamentData.balls, WEIGHTS.BALLS);
    updateInstance(giftsRef, ornamentData.gifts, WEIGHTS.GIFTS);
    updateInstance(lightsRef, ornamentData.lights, WEIGHTS.LIGHTS);
  });

  return (
    <group ref={groupRef}>
      {/* Foliage Points */}
      <points ref={foliagePointsRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={FOLIAGE_COUNT} array={foliagePointsData.treePositions} itemSize={3} />
          <bufferAttribute attach="attributes-scatterPos" count={FOLIAGE_COUNT} array={foliagePointsData.scatterPositions} itemSize={3} />
          <bufferAttribute attach="attributes-treePos" count={FOLIAGE_COUNT} array={foliagePointsData.treePositions} itemSize={3} />
          <bufferAttribute attach="attributes-aRandom" count={FOLIAGE_COUNT} array={foliagePointsData.randoms} itemSize={1} />
        </bufferGeometry>
        <shaderMaterial 
          ref={foliageMaterialRef}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          {...foliageShader}
        />
      </points>

      {/* Metallic Balls */}
      <instancedMesh ref={ballsRef} args={[undefined, undefined, ORNAMENT_COUNTS.BALLS]} castShadow>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial 
          color={COLORS.GOLD_METALLIC} 
          metalness={1} 
          roughness={0.05} 
          envMapIntensity={2}
        />
      </instancedMesh>

      {/* Luxury Gift Boxes */}
      <instancedMesh ref={giftsRef} args={[undefined, undefined, ORNAMENT_COUNTS.GIFTS]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial 
          color={COLORS.GIFT_RED} 
          metalness={0.8} 
          roughness={0.2} 
        />
      </instancedMesh>

      {/* Glowing Light Points */}
      <instancedMesh ref={lightsRef} args={[undefined, undefined, ORNAMENT_COUNTS.LIGHTS]}>
        <sphereGeometry args={[0.3, 8, 8]} />
        <meshStandardMaterial 
          color={COLORS.GOLD_BRIGHT} 
          emissive={COLORS.GOLD_BRIGHT} 
          emissiveIntensity={4} 
        />
      </instancedMesh>

      {/* Signature Star */}
      <mesh position={[0, TREE_HEIGHT / 2 + 0.4, 0]} scale={status === TreeMorphStatus.TREE_SHAPE ? 1.2 : 0}>
        <octahedronGeometry args={[0.6, 0]} />
        <meshStandardMaterial 
          color={COLORS.GOLD_BRIGHT} 
          emissive={COLORS.GOLD_METALLIC} 
          emissiveIntensity={config.lightIntensity * 5} 
        />
      </mesh>

      <Sparkles 
        count={200} 
        scale={SCATTER_RADIUS * 1.5} 
        size={2} 
        speed={0.3} 
        color={COLORS.GOLD_BRIGHT} 
      />
    </group>
  );
};

export default ChristmasTree;
